import tkinter as tk
import os
import time

from tkcalendar import DateEntry, Calendar
from tkinter import ttk
from tkinter import messagebox
from tkinter import filedialog

from notifiers import get_notifier

from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager


token = r'5947468379:AAGXSZYSj0rXKqWUtPEsNvtSCbSNzbqSUhU'

months_en = {
    'January': '01',
    'February': '02',
    'March': '03',
    'April': '04',
    'May': '05',
    'June': '06',
    'July': '07',
    'August': '08',
    'September': '09',
    'October': '10',
    'November': '11',
    'December': '12'
}

def send_msg(token, id, msg):
    bot = get_notifier('telegram')
    bot.notify(token=token, chat_id=id, message=msg)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Visa Script')
        self.resizable(width=False, height=False)
        self['background'] = '#232831'
        self.conf = {'padx': (10, 10), 'pady': 10}
        self.basic_font = 'Helvetica 13'
        self.bold_font = 'Helvetica 13 bold'
        self.put_frames()

    def put_frames(self):
        self.add_form_frame = AddForm(self).grid(row=0, column=0, sticky='nswe')

class AddForm(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self['background'] = self.master['background']
        self.put_widgets()

    def put_widgets(self):
        self.tg_id = ttk.Label(self, text='Telegram id', font=self.master.basic_font, anchor='center')
        self.tg_id_choose = ttk.Entry(self, font=self.master.basic_font, justify=tk.CENTER)

        self.sleep_time = ttk.Label(self, text='Сколько времени ждать?', font=self.master.basic_font, anchor='center')
        self.sleep_time_entry = ttk.Entry(self, font=self.master.basic_font, justify=tk.CENTER)

        self.accs_file = ttk.Label(self, text='Файл с аккаунтами', font=self.master.basic_font, anchor='center')
        self.accs_file_choose = ttk.Button(self, text='Выбрать файл', command=self.file_choose)
        self.date_from = ttk.Label(self, text='Искать с', font=self.master.basic_font, anchor='center')
        self.date_from_choose = DateEntry(self, foreground='black', normalground='black',
                                     selectforeground='red', background='white',
                                     date_pattern='dd-mm-YYYY', font=self.master.basic_font)
        self.date_to = ttk.Label(self, text='Искать до', font=self.master.basic_font, anchor='center')
        self.date_to_choose = DateEntry(self, foreground='black', normalground='black',
                                   selectforeground='red', background='white',
                                   date_pattern='dd-mm-YYYY', font=self.master.basic_font)
        self.btn_save_tg_id = ttk.Button(self, text='Сохранить Telegram id', command=self.tg_id_submit)

        self.btn_sleep_time_save = ttk.Button(self, text='Сохранить время', command=self.save_sleep_time)

        self.btn_save_dates = ttk.Button(self, text='Сохранить даты', command=self.dates_submit)
        self.btn_check_settings = ttk.Button(self, text='Проверить настройки', command=self.check_settings)
        self.btn_start = ttk.Button(self, text='Начать', command=self.get_dates)
        self.date_from_choose._top_cal.overrideredirect(False)
        self.date_to_choose._top_cal.overrideredirect(False)

        self.tg_id.grid(row=0, column=0, sticky='we', cnf=self.master.conf)
        self.tg_id_choose.grid(row=0, column=1, sticky='w', cnf=self.master.conf)
        self.tg_id_choose.insert(0, '146635092')
        self.btn_save_tg_id.grid(row=0, column=2, sticky='n', cnf=self.master.conf)

        self.accs_file.grid(row=1, column=0, sticky='we', cnf=self.master.conf)
        self.accs_file_choose.grid(row=1, column=1, columnspan=2, sticky='we', cnf=self.master.conf)

        self.date_from.grid(row=2, column=0, sticky='we', cnf=self.master.conf)
        self.date_from_choose.grid(row=2, column=1, columnspan=2, sticky='we', cnf=self.master.conf)

        self.date_to.grid(row=3, column=0, sticky='we', padx=10, cnf=self.master.conf)
        self.date_to_choose.grid(row=3, column=1, columnspan=2, sticky='we', cnf=self.master.conf)

        self.btn_save_dates.grid(row=4, column=0, columnspan=3, sticky='we', cnf=self.master.conf)

        self.sleep_time.grid(row=5, column=0, sticky='we', padx=10, cnf=self.master.conf)
        self.sleep_time_entry.grid(row=5, column=1, sticky='w', padx=10, cnf=self.master.conf)
        self.sleep_time_entry.insert(0, 'Время в минутах')
        self.btn_sleep_time_save.grid(row=5, column=2, sticky='we', padx=10, cnf=self.master.conf)

        self.btn_check_settings.grid(row=6, column=0, columnspan=3, sticky='we', cnf=self.master.conf)

        self.btn_start.grid(row=7, column=0, columnspan=3, sticky='n', cnf=self.master.conf)

    def tg_id_submit(self):
        id = self.tg_id_choose.get()

        with open('tg_id.txt', "w", encoding='utf-8') as f:
            f.write(id)
        messagebox.showinfo('Telegram id', f'Сохранен id: {id}')

    def dates_submit(self):
        date_from_gui = self.date_from_choose.get()
        date_to_gui = self.date_to_choose.get()

        date_from_gui_splited = date_from_gui.split('-')
        date_to_gui_splited = date_to_gui.split('-')

        date_from = date_from_gui_splited[-1] + date_from_gui_splited[1] + date_from_gui_splited[0]

        date_to = date_to_gui_splited[-1] + date_to_gui_splited[1] + date_to_gui_splited[0]

        with open('date_from.txt', "w", encoding='utf-8') as f:
            f.write(date_from)

        with open('date_to.txt', "w", encoding='utf-8') as f:
            f.write(date_to)

        messagebox.showinfo('Даты', f'Сохранены даты (ДД-ММ-ГГГГ):\n'
                                    f'Дата начала поиска: {date_from_gui}\n'
                                    f'Дата окончания поиска: {date_to_gui}')

    def file_choose(self):
        file = filedialog.askopenfilename(initialdir="/", title="Select a File",
                                          filetypes=(("All types",".*"), ("all files", "*.*")))
        file_abspath = os.path.abspath(file)

        with open('abspath_of_file.txt', "w", encoding='utf-8') as f:
            f.write(file_abspath)

    def save_sleep_time(self):
        with open('time.txt', "w", encoding='utf-8') as f:
            f.write(self.sleep_time_entry.get())

        messagebox.showinfo('Время ожидания', f'Сохранено время: {self.sleep_time_entry.get()} мин')

    def check_settings(self):
        with open('date_from.txt', "r", encoding='utf-8') as f:
            date_from = f.read()

        with open('date_to.txt', "r", encoding='utf-8') as f:
            date_to = f.read()

        with open('abspath_of_file.txt', "r", encoding='utf-8') as f:
            file_abspath = f.read()

        with open('tg_id.txt', "r", encoding='utf-8') as f:
            id = f.read()

        with open('time.txt', 'r', encoding='utf-8') as f:
            time = f.read()

        messagebox.showinfo('Сохраненные настройки',
                            f'Дата начала поиска: {date_from} (ГГГГммдд)\n'
                            f'Дата окончания поиска: {date_to} (ГГГГммдд)\n'
                            f'Путь к файлу с аккаунтами: {file_abspath}\n'
                            f'Время между проверками: {time} минут\n'
                            f'Telegram id: {id}')

    def get_dates(self):
        with open('time.txt', 'r', encoding='utf-8') as f:
            time_to_sleep = int(f.read())

        while True:
            accs = []
            counter = 0

            with open('abspath_of_file.txt', 'r', encoding='utf-8') as f:
                file = f.read()

            with open(file, 'r', encoding='utf-8') as file:
                for line in file.readlines():
                    accs.append(line.split(' '))

            accs_amount = len(accs)

            for acc in accs:
                with open('date_from.txt', 'r', encoding='utf-8') as f:
                    date_from = f.read()
                    date_from = int(date_from)

                with open('date_to.txt', 'r', encoding='utf-8') as f:
                    date_to = f.read()
                    date_to = int(date_to)

                with open('tg_id.txt', 'r', encoding='utf-8') as f:
                    id = f.read()

                options = webdriver.ChromeOptions()
                #options.add_argument('headless')
                options.add_argument('--no-sandbox')
                options.add_argument('--disable-dev-shm-usage')
                options.add_argument('--disable-blink-features=AutomationControlled')
                options.add_argument('--enable-experimental-cookie-features')

                url = f'https://ais.usvisa-info.com/{acc[0]}/niv/users/sign_in'
                driver = webdriver.Chrome(ChromeDriverManager().install(), options=options)
                try:
                    driver.get(url=url)
                    time.sleep(1)

                    try:
                        driver.find_element_by_xpath('//a[text()="Sign Out"]').click()

                    except Exception:
                        pass

                    finally:
                        email_input = driver.find_element_by_xpath('//input[@type ="email"]')
                        email_input.clear()
                        email_input.send_keys(acc[1])

                        pass_input = driver.find_element_by_xpath('//input[@type="password"]')
                        pass_input.clear()
                        pass_input.send_keys(acc[2])

                        accept_box = driver.find_element_by_xpath('//div[@style="position: relative;"]')
                        accept_box.click()
                        time.sleep(2)

                        try:
                            try:
                                ok_butt = driver.find_element_by_xpath('//button[text()="OK"]')
                                ok_butt.click()
                                time.sleep(2)

                            finally:
                                login_butt = driver.find_element_by_xpath('//input[@type="submit"]')
                                login_butt.click()
                                time.sleep(2)

                                try:
                                    error = driver.find_element_by_xpath('//p[@class="error animated bounceIn"]')
                                    if error:
                                        send_msg(token, id, f'📛 Неправильный пароль 📛\n\n'
                                                            f'🌎 {acc[0]}\n'
                                                            f'Логин: {acc[1]}\n'
                                                            f'Пароль: {acc[2]}')

                                except Exception:
                                    cont_butts = driver.find_elements_by_xpath('//a[@class="button primary small"]')

                                    if len(cont_butts) != 0:
                                        for butt in cont_butts:
                                            url = butt.get_attribute('href')

                                            new_window = driver.execute_script('window.open()')
                                            driver.switch_to.window(driver.window_handles[1])
                                            driver.get(url=url)
                                            time.sleep(2)

                                            pay_tab = driver.find_element_by_xpath('//a[@class="accordion-title"]')
                                            pay_tab.click()
                                            time.sleep(2)

                                            try:
                                                pay_butt = driver.find_element_by_xpath('//a[text()="Pay Visa Fee"]')
                                                pay_butt.click()
                                                time.sleep(2)

                                                available_dates = driver.find_elements_by_xpath(
                                                    '//td[@class="text-right"]')
                                                str_dates = []

                                                for date in available_dates:
                                                    date = date.text.split()
                                                    str_dates.append(date)

                                                sorted_dates = []
                                                for date in str_dates:
                                                    sorted_date = []
                                                    for date_elem in date:
                                                        date_elem = date_elem.strip(',')
                                                        if len(date_elem) < 2:
                                                            date_elem = f'0{date_elem}'
                                                            sorted_date.append(date_elem)
                                                        elif date_elem in months_en.keys():
                                                            date_elem = months_en[date_elem]
                                                            sorted_date.append(date_elem)
                                                        else:
                                                            sorted_date.append(date_elem)
                                                    sorted_dates.append(sorted_date)

                                                dates = []
                                                for date in sorted_dates:
                                                    dates.append(f'{date[-1]}{date[1]}{date[0]}')

                                                person_info = driver.find_elements_by_xpath('//td')
                                                name = person_info[0].text
                                                bd = person_info[1].text
                                                nation = person_info[2].text
                                                ds = person_info[3].text
                                                time.sleep(2)

                                                for date in dates:
                                                    date_for_bot = f'{date[6:8]}-{date[4:6]}-{date[0:4]}\n' \
                                                                   f'ДД-ММ-ГГГГ'
                                                    if date != 'AvailableAppointmentsNo':
                                                        date = int(date)
                                                        if date >= date_from and date <= date_to:
                                                            send_msg(token, id, f'✅ Свободная дата найдена ✅\n\n'
                                                                                f'‍Аккаунт:\n'
                                                                                f'🌎 {acc[0]}\n'
                                                                                f'✉ {acc[1]}\n'
                                                                                f'🔐 {acc[2]}\n\n'
                                                                                f'Человек:\n'
                                                                                f'Имя: {name}\n'
                                                                                f'Дата рождения: {bd}\n'
                                                                                f'Гражданство: {nation}\n'
                                                                                f'DS-160: {ds}\n\n'
                                                                                f'🗓 Свободна дата: {date_for_bot}')
                                                        else:
                                                            send_msg(token, id, f'❔ Свободная дата вне интервала ❔\n\n'
                                                                                f'‍Аккаунт:\n'
                                                                                f'🌎 {acc[0]}\n'
                                                                                f'✉ {acc[1]}\n'
                                                                                f'🔐 {acc[2]}\n\n'
                                                                                f'Человек:\n'
                                                                                f'Имя: {name}\n'
                                                                                f'Дата рождения: {bd}\n'
                                                                                f'Гражданство: {nation}\n'
                                                                                f'DS-160: {ds}\n\n'
                                                                                f'🗓 Свободна дата: {date_for_bot}')
                                                    else:
                                                        send_msg(token, id, f'📛 Свободных дат нет 📛\n\n'
                                                                            f'‍Аккаунт:\n'
                                                                            f'🌎 {acc[0]}\n'
                                                                            f'✉ {acc[1]}\n'
                                                                            f'🔐 {acc[2]}\n\n'
                                                                            f'Человек:\n'
                                                                            f'Имя: {name}\n'
                                                                            f'Дата рождения: {bd}\n'
                                                                            f'Гражданство: {nation}\n'
                                                                            f'DS-160: {ds}\n\n'
                                                                            f'🗓 Свободна дата: НЕТ')

                                            except Exception:
                                                send_msg(token, id, f'📛 Проблема с платежом 📛\n\n'
                                                                    f'‍Аккаунт:\n'
                                                                    f'🌎 {acc[0]}\n'
                                                                    f'✉ {acc[1]}\n'
                                                                    f'🔐 {acc[2]}\n\n')

                                            finally:
                                                driver.close()
                                                driver.switch_to.window(driver.window_handles[0])

                        except Exception:
                            pass

                except Exception as ex:
                    print(ex)

                finally:
                    driver.close()
                    driver.quit()
                    counter += 1

            if counter == accs_amount:
                time.sleep(10)
                send_msg(token, id, f'✅ Все {accs_amount} аккаунтов проверены ✅\n\n')
                time.sleep(time_to_sleep * 60)

app = App()
app.mainloop()
