import time

from bot import *
from data import months_en
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager


def get_data(pathfile, date_from_file, date_to_file, tg_id_file, time_file):
    with open(time_file, 'r', encoding='utf-8') as f:
        time_to_sleep = int(f.read())

    while True:
        accs = []
        counter = 0

        with open(pathfile, 'r', encoding='utf-8') as f:
            file = f.read()

        with open(file, 'r', encoding='utf-8') as file:
            for line in file.readlines():
                accs.append(line.split(' '))

        accs_amount = len(accs)

        for acc in accs:
            with open(date_from_file, 'r', encoding='utf-8') as f:
                date_from = f.read()
                date_from = int(date_from)

            with open(date_to_file, 'r', encoding='utf-8') as f:
                date_to = f.read()
                date_to = int(date_to)

            with open(tg_id_file, 'r', encoding='utf-8') as f:
                id = f.read()

            options = webdriver.ChromeOptions()
            options.add_argument('headless')
            options.add_argument('--no-sandbox')
            options.add_argument('--disable-dev-shm-usage')
            options.add_argument('--disable-blink-features=AutomationControlled')
            options.add_argument('--enable-experimental-cookie-features')

            url = f'https://ais.usvisa-info.com/{acc[0]}/niv/users/sign_in'
            driver = webdriver.Chrome(ChromeDriverManager().install(), chrome_options=options)
            try:
                driver.get(url=url)
                time.sleep(1)

                try:
                    driver.find_element_by_xpath('//a[text()="Sign Out"]').click()

                except Exception:
                    pass

                finally:
                    email_input = driver.find_element_by_xpath('//input[@type ="email"]')
                    email_input.clear()
                    email_input.send_keys(acc[1])

                    pass_input = driver.find_element_by_xpath('//input[@type="password"]')
                    pass_input.clear()
                    pass_input.send_keys(acc[2])

                    accept_box = driver.find_element_by_xpath('//div[@style="position: relative;"]')
                    accept_box.click()
                    time.sleep(2)

                    try:
                        try:
                            ok_butt = driver.find_element_by_xpath('//button[text()="OK"]')
                            ok_butt.click()
                            time.sleep(2)

                        finally:
                            login_butt = driver.find_element_by_xpath('//input[@type="submit"]')
                            login_butt.click()
                            time.sleep(2)

                            try:
                                error = driver.find_element_by_xpath('//p[@class="error animated bounceIn"]')
                                if error:
                                    send_msg(token, id, f'📛 Неправильный пароль 📛\n\n'
                                                        f'🌎 {acc[0]}\n'
                                                        f'Логин: {acc[1]}\n'
                                                        f'Пароль: {acc[2]}')

                            except Exception:
                                cont_butts = driver.find_elements_by_xpath('//a[@class="button primary small"]')

                                if len(cont_butts) != 0:
                                    for butt in cont_butts:
                                        url = butt.get_attribute('href')

                                        new_window = driver.execute_script('window.open()')
                                        driver.switch_to.window(driver.window_handles[1])
                                        driver.get(url=url)
                                        time.sleep(2)

                                        pay_tab = driver.find_element_by_xpath('//a[@class="accordion-title"]')
                                        pay_tab.click()
                                        time.sleep(2)

                                        try:
                                            pay_butt = driver.find_element_by_xpath('//a[text()="Pay Visa Fee"]')
                                            pay_butt.click()
                                            time.sleep(2)

                                            available_dates = driver.find_elements_by_xpath('//td[@class="text-right"]')
                                            str_dates = []

                                            for date in available_dates:
                                                date = date.text.split()
                                                str_dates.append(date)

                                            sorted_dates = []
                                            for date in str_dates:
                                                sorted_date = []
                                                for date_elem in date:
                                                    date_elem = date_elem.strip(',')
                                                    if len(date_elem) < 2:
                                                        date_elem = f'0{date_elem}'
                                                        sorted_date.append(date_elem)
                                                    elif date_elem in months_en.keys():
                                                        date_elem = months_en[date_elem]
                                                        sorted_date.append(date_elem)
                                                    else:
                                                        sorted_date.append(date_elem)
                                                sorted_dates.append(sorted_date)

                                            dates = []
                                            for date in sorted_dates:
                                                dates.append(f'{date[-1]}{date[1]}{date[0]}')

                                            person_info = driver.find_elements_by_xpath('//td')
                                            name = person_info[0].text
                                            bd = person_info[1].text
                                            nation = person_info[2].text
                                            ds = person_info[3].text
                                            time.sleep(2)

                                            for date in dates:
                                                date_for_bot = f'{date[6:8]}-{date[4:6]}-{date[0:4]}\n' \
                                                               f'ДД-ММ-ГГГГ'
                                                if date != 'AvailableAppointmentsNo':
                                                    date = int(date)
                                                    if date >= date_from and date <= date_to:
                                                        send_msg(token, id, f'✅ Свободная дата найдена ✅\n\n'
                                                                            f'‍Аккаунт:\n'
                                                                            f'🌎 {acc[0]}\n'
                                                                            f'✉ {acc[1]}\n'
                                                                            f'🔐 {acc[2]}\n\n'
                                                                            f'Человек:\n'
                                                                            f'Имя: {name}\n'
                                                                            f'Дата рождения: {bd}\n'
                                                                            f'Гражданство: {nation}\n'
                                                                            f'DS-160: {ds}\n\n'
                                                                            f'🗓 Свободна дата: {date_for_bot}')
                                                    else:
                                                        send_msg(token, id, f'❔ Свободная дата вне интервала ❔\n\n'
                                                                            f'‍Аккаунт:\n'
                                                                            f'🌎 {acc[0]}\n'
                                                                            f'✉ {acc[1]}\n'
                                                                            f'🔐 {acc[2]}\n\n'
                                                                            f'Человек:\n'
                                                                            f'Имя: {name}\n'
                                                                            f'Дата рождения: {bd}\n'
                                                                            f'Гражданство: {nation}\n'
                                                                            f'DS-160: {ds}\n\n'
                                                                            f'🗓 Свободна дата: {date_for_bot}')
                                                else:
                                                    send_msg(token, id, f'📛 Свободных дат нет 📛\n\n'
                                                                        f'‍Аккаунт:\n'
                                                                        f'🌎 {acc[0]}\n'
                                                                        f'✉ {acc[1]}\n'
                                                                        f'🔐 {acc[2]}\n\n'
                                                                        f'Человек:\n'
                                                                        f'Имя: {name}\n'
                                                                        f'Дата рождения: {bd}\n'
                                                                        f'Гражданство: {nation}\n'
                                                                        f'DS-160: {ds}\n\n'
                                                                        f'🗓 Свободна дата: НЕТ')

                                        finally:
                                            driver.close()
                                            driver.switch_to.window(driver.window_handles[0])

                    except Exception:
                        pass

            except Exception as ex:
                print(ex)

            finally:
                driver.close()
                driver.quit()
                counter += 1
        if counter == accs_amount:
            time.sleep(10)
            send_msg(token, id, f'✅ Все {accs_amount} аккаунтов проверены ✅\n\n')
            time.sleep(time_to_sleep*60)
