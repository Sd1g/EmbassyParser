from notifiers import get_notifier
from data import token


def send_msg(token, id, msg):
    bot = get_notifier('telegram')
    bot.notify(token=token, chat_id=id, message=msg)